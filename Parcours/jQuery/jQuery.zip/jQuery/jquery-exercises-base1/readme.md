# Exercices jQuery

**IMPORTANT**

Les fichiers HTML et jQuery sont fournis. **Attention**. Comme pour Bootstrap, on ne modifie pas le fichier jQuery.

## Exercice 1 :

Cacher la div "texte".

## Exercice 2 :

Afficher la div "texte".

## Exercice 3 :

Changer le font-family de la div "texte" en "Courier".

## Exercice 4 :

Changer la couleur de toutes les balises "li" en rouge

## Exercice 5 :

Vider la div "texte_2"

## Exercice 6 :

Cacher tous les éléments de la classe "a_cacher".

## Exercice 7 :

Supprimer tous les éléments de la classe "a_supprimer".

## Exercice 8 :

Donner à tous les éléments "li" enfants de "ol" la couleur rouge.

## Exercice 9 :

Donner aux div "texte_1" et "texte_3" une bordure de 5 pixels, verte à pointillés ("5px green dashed").

## Exercice 10 :

Du JQuery est déjà présent et permet de cacher tous les éléments de la classe "a_cacher". Ajouter cette classe à la div "texte_3".
